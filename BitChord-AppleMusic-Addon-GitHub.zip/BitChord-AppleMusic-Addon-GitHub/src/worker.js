const manifest = {
  id: "dev.vaidheshwaranarasu1.applemusic-preview",
  name: "Apple Music Catalog Preview",
  version: "1.0.0",
  resources: ["search", "stream"],
  allowDownloads: 0,
  checkValidLossless: 0,
  settings: [{
    key: "quality",
    type: "select",
    label: "Preview quality",
    default: "preview",
    options: [{ value: "preview", label: "Apple catalog preview (AAC)" }]
  }]
};
const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type",
  "Cache-Control": "no-store"
};
function json(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { ...cors, "Content-Type": "application/json; charset=utf-8" }
  });
}
function normalizeTrack(item) {
  const artwork = item.artworkUrl100 ? item.artworkUrl100.replace("100x100bb", "600x600bb") : "";
  return {
    id: String(item.trackId || item.collectionId || ""),
    title: item.trackName || item.collectionName || "Unknown title",
    artist: item.artistName || "Unknown artist",
    album: item.collectionName || "",
    duration: item.trackTimeMillis ? Math.round(item.trackTimeMillis / 1000) : undefined,
    artworkURL: artwork || undefined,
    format: "AAC",
    audioQuality: "PREVIEW",
    streamURL: item.previewUrl || undefined
  };
}
export default {
  async fetch(request) {
    const url = new URL(request.url);
    if (request.method === "OPTIONS") return new Response(null, { status: 204, headers: cors });
    if (url.pathname === "/manifest.json") return json(manifest);
    if (url.pathname === "/") return json({ addon: manifest.name, status: "ok", manifest: "/manifest.json" });
    if (url.pathname === "/search") {
      const q = (url.searchParams.get("q") || "").trim();
      if (!q) return json({ tracks: [] });
      const api = new URL("https://itunes.apple.com/search");
      api.searchParams.set("term", q);
      api.searchParams.set("entity", "song");
      api.searchParams.set("limit", "25");
      api.searchParams.set("media", "music");
      const response = await fetch(api.toString(), { headers: { "User-Agent": "BitChord-AppleCatalogAddon/1.0" } });
      if (!response.ok) return json({ tracks: [], error: "Catalog search unavailable" }, 502);
      const data = await response.json();
      return json({ tracks: (data.results || []).filter(x => x.previewUrl && x.trackId).map(normalizeTrack) });
    }
    if (url.pathname.startsWith("/stream/")) {
      const trackId = decodeURIComponent(url.pathname.slice("/stream/".length));
      const lookup = new URL("https://itunes.apple.com/lookup");
      lookup.searchParams.set("id", trackId);
      lookup.searchParams.set("entity", "song");
      const response = await fetch(lookup.toString());
      if (!response.ok) return json({ error: "Catalog lookup failed" }, 502);
      const data = await response.json();
      const item = (data.results || []).find(row => String(row.trackId) === trackId && row.previewUrl);
      if (!item) return json({ error: "Preview unavailable for this track" }, 404);
      return json({ url: item.previewUrl, format: "AAC", quality: "Apple catalog preview", codec: "aac", container: "mp4", manifest: "none", encrypted: false });
    }
    return json({ error: "Not found" }, 404);
  }
};
