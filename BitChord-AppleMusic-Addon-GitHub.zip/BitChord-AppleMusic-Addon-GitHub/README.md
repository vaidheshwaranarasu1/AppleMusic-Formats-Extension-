# BitChord Apple Music Catalog Preview Addon

A small Cloudflare Worker addon backend for BitChord that searches Apple's public catalog and resolves available preview clips.


## Features
- Search catalog metadata (song, artist, album, artwork).
- Preview clips only, when Apple provides a preview URL.
- Preview quality is labeled AAC; no claims of full-track Apple Music streaming or Hi-Res Lossless.
- Downloads disabled.

## Deploy
1. Sign in to Cloudflare and open **Workers & Pages**.
2. Create a Worker and choose a name.
3. Copy `src/worker.js` into the Worker editor.
4. Deploy.
5. Check `https://YOUR-WORKER.workers.dev/manifest.json` returns JSON.
6. In BitChord, Sources → Add an addon and enter the Worker URL.

## Endpoints
- `GET /manifest.json` - addon manifest
- `GET /search?q=query` - search results
- `GET /stream/{trackId}` - resolves preview audio details

## Limitations
Apple public catalog APIs provide preview audio only for some tracks, often short clips. This addon does not provide full Apple Music subscriber streaming, Hi-Res Lossless, or Atmos.

## Project status
Community/unofficial addon; not affiliated with Apple or BitChord. Check BitChord's current addon API requirements before deploying if its protocol changes.
